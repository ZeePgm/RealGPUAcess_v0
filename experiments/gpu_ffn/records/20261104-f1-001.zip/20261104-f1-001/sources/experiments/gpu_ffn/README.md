# Full FFN expansion: F1

F1 executes Qwen3-0.6B on the GPU, with its original F16 KV cache, and gates
the complete layer-10 FFN gate/up/down matrices through HBF-EventLab. The three
F16 matrices contain 18 MiB. A stable 84-matrix layout reserves their addresses
at 180, 186 and 192 MiB in a 512 MiB logical device; only the selected matrices
are registered and initialized.

The entry point compiles the S8 CUDA executor with separate FFN gate/segment
headers. Existing S8 builds retain their original headers and behavior. The
backend and llama runtime are built from this workspace, in a separate directory.
No sealed or historical build is overwritten.

## Build and run

From the repository root, with Python/NumPy, Visual Studio 2022 C++ tools and
CUDA/CUPTI installed:

```powershell
./experiments/gpu_ffn/build.ps1 -CudaRoot <CUDA-directory> -BuildDir ./build-ffn
python -m unittest discover -s experiments/gpu_ffn -p test_run.py -v
python experiments/gpu_ffn/run.py --model <Qwen3-0.6B-F16.gguf> --cuda-root <CUDA-directory> --output output/gpu-ffn/f1-001
```

The default GPU target is the local validated SM 120a; use `-CudaArchitectures`
to select a different target. Every run requires a new output directory. Use
`--prepare-only` to inspect the actual GGUF layout, model hash, selected regions,
H0 configuration and expected counts without running GPU inference. `--timeout`
sets the wall-time budget per subprocess (default 3600 seconds). Interrupted or
failed outputs are retained and must not be reused as a fresh output directory.

The default prompt is the original S-series input. One native request captures
kernel/memcpy/memset activity in synchronized windows and exports complete logits.
The runner freezes the per-window GPU interval unions into a compute table. One
F1 request consumes that exact table while performing real GPU work and HBF
accesses. Both use one-node dispatch, F32 matrix accumulation and native F16 KV;
no intermediate-array snapshots are written.

## Lightweight backend audit

`OnlineAudit` independently checks the manifest's expected address intervals,
ordered Global/fragment identities, exact 4 KiB/64 B coverage, terminal outcomes,
and parent completion at the maximum child completion time. It discards completed
fragment and attempt entries. Observer memory therefore follows live work rather
than all cumulative accesses. Only parent-level gate results are exported.

The Host still retains its own completed Global/version history. Peak process
working set is measured on Windows; bounded observer maps do not imply constant
total process memory. CUPTI kernel/API/window records remain available for the
selected-consumer launch-order audit. These are small GPU records, not millions
of backend fragment rows.

The runner checks native/F1 consumer sequences, complete logits and tokens,
actual per-step FFN coverage, ordinary initialization, online fragment totals,
Host success, close/drain, every compute-table entry, selected CUDA launch API
ordering, and integer time conservation. With eight inference steps the expected
counts are 24 parent reads, 36,864 read Globals, 2,359,296 read fragments and
294,912 initialization fragments. EOS is retained separately; useful-token
metrics and expectations use the actual executed steps.

## Outputs and interpretation

- `layout-all-ffn.json`, `regions.json`, `plan.json`, prompt and full effective INI.
- `build-identity.json`: model-run binary, runtime DLL, build cache and source hashes.
- `native/` and `F1/`: execution/segment/API/kernel records, full logits and summaries.
- `F1/gates.jsonl`, `tokens.jsonl`, `session.json`: parent accesses, modeled token
  times, bounded-audit counters and backend final state.
- `compute-table.json`, `paired-tokens.csv`, `result.json`, process commands/logs
  and an artifact hash index. Errors produce `runner-failure.json`.

TTFT/TPOT and waits in `result.json` use modeled picoseconds. Whole-process wall
time, backend initialization/read-call/finish time, and peak working set are
software costs reported separately. A single native activity trace supports a
fixed-trace mechanism comparison, not a timing distribution or hardware prediction.
Real weights remain in GPU storage; this experiment does not implement physical
weight offload. F2/F3 are not run by this entry point.
