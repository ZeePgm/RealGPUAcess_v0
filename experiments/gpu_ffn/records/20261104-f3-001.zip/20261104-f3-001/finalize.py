"""Archive verified F3 results and produce the three-stage comparison report."""
import copy
from datetime import datetime, timedelta, timezone
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT/'experiments/gpu_ffn'))
import run as f

out = Path(__file__).resolve().parent
result = f.read(out/'result.json')
f.require(result['stage'] == 'F3' and result['status'] == 'pass', 'F3 must finish successfully')
subprocess.run([sys.executable, str(ROOT/'experiments/gpu_ffn/validate.py'),
                '--output', str(out), '--negative-checks'], check=True)
identity = f.read(out/'build-identity.json')
for name, digest in identity['sources'].items():
    snapshot = out/'sources'/name
    source = snapshot if snapshot.is_file() else ROOT/name
    f.require(f.sha(source) == digest, 'Run source identity mismatch: '+name)
f.require(f.sha(ROOT/'build-ffn/bin/gpu_ffn.exe') == identity['binary_sha256'], 'Binary mismatch')
for name, digest in identity['runtime_dlls'].items():
    f.require(f.sha(ROOT/'build-ffn/bin'/name) == digest, 'Runtime mismatch: '+name)

stages = {}
for stage in ('F1', 'F2', 'F3'):
    folder = out.parent/('20261104-'+stage.lower()+'-001')
    r = f.read(folder/'result.json')
    f.require(r['status'] == 'pass', 'Unpassed comparison stage')
    f.require(f.sha(folder/'compute-table.json') == f.sha(out/'compute-table.json'), 'Compute table differs')
    f.require(f.sha(folder/'H0-512MiB.ini') == f.sha(out/'H0-512MiB.ini'), 'HBF configuration differs')
    f.require(r['G2'] == result['G2'], 'Zero-wait baseline differs')
    f.require(r['online_audit']['attempt_errors'] == r['online_audit']['logical_failures'] == 0, 'Unexpected attempt/logical failure')
    selection = f.read(folder/'regions.json')
    full = {r['tensor']: r for r in f.read(out/'regions.json')}
    f.require(all(full[r['tensor']] == r for r in selection), 'Prior stage addresses differ')
    stages[stage] = r

native = f.read(out/'native/summary.json')
compact = copy.deepcopy(result)
for cost in compact['software_costs'].values():
    cost.pop('argv', None)
completed_at = datetime.now(timezone(timedelta(hours=8)))
compact.update(date=completed_at.date().isoformat(), completed_at=completed_at.isoformat(),
               batch_started_date='2026-11-04', batch=str(out.relative_to(ROOT)), model_id='Qwen/Qwen3-0.6B',
               model_sha256=f.read(out/'plan.json')['model_sha256'], prompt_tokens=len(native['prompt_ids']),
               generated_tokens=native['tokens'], capacity_bytes=512*1024**2,
               compute_table_sha256=f.sha(out/'compute-table.json'),
               build_identity_sha256=f.sha(out/'build-identity.json'),
               source_and_runtime_hashes_verified=True, source_files_verified=len(identity['sources']),
               validation={'python_unit_checks': 10, 'saved_record_negative_cases_rejected': 5},
               comparison={stage: {'coverage_bytes': r['coverage']['registered_valid_bytes'],
                                  'total_wait_ps': r['total_wait_ps'],
                                  'G3': r['G3'],
                                  'process_wall_seconds': r['software_costs'][stage]['process_wall_seconds'],
                                  'peak_working_set_bytes': r['software_costs'][stage]['peak_working_set_bytes']}
                           for stage, r in stages.items()})
f.write(ROOT/'docs/validation/gpu-f3.json', compact)

def milliseconds(value): return f'{value/1e9:.9f}'.rstrip('0').rstrip('.')
def comparison_row(label, get):
    return '| '+label+' | '+' | '.join(get(stage, r) for stage, r in stages.items())+' |'

comparison = '\n'.join([
    comparison_row('矩阵 / 登记量', lambda s,r: f"{r['coverage']['registered_valid_bytes']//(6*1024**2)} / {r['coverage']['registered_valid_bytes']//1024**2} MiB"),
    comparison_row('累计有效读取', lambda s,r: f"{r['coverage']['cumulative_read_bytes']//1024**2} MiB"),
    comparison_row('父读数', lambda s,r: str(r['coverage']['parent_reads'])),
    comparison_row('模拟 TTFT（ms）', lambda s,r: milliseconds(r['G3']['ttft_ps'])),
    comparison_row('模拟平均 TPOT（ms）', lambda s,r: milliseconds(r['G3']['tpot_ps'])),
    comparison_row('模拟最后 token 时刻（ms）', lambda s,r: milliseconds(r['compute_ps']+r['total_wait_ps'])),
    comparison_row('模拟累计 HBF 等待（ms）', lambda s,r: milliseconds(r['total_wait_ps'])),
    comparison_row('软件进程墙钟（s）', lambda s,r: f"{r['software_costs'][s]['process_wall_seconds']:.3f}"),
    comparison_row('峰值 working set（MiB）', lambda s,r: f"{r['software_costs'][s]['peak_working_set_bytes']/1024**2:.3f}"),
])
gates = f.rows(out/'F3/gates.jsonl')
token_rows = f.rows(out/'F3/tokens.jsonl')
per_token = '\n'.join('| '+str(i)+' | '+str(t['token_id'])+' | '+milliseconds(t['compute_ps'])+' | '+milliseconds(t['wait_ps'])+' | '+milliseconds(t['relative_ps'])+' | 0 |' for i,t in enumerate(token_rows))
cost = result['software_costs']['F3']
phases = result['measured_software_phases_seconds']
coverage = result['coverage']
report = f'''# F3：全 FFN 验收与 F1—F3 总结

批次：`output/gpu-ffn/20261104-f3-001/`。**F3 已完成实际运行并通过验证，F1—F3 全部完成。** 验收时间：{completed_at.isoformat(timespec='seconds')}（北京时间）；批次于 2026-11-04 启动。

## 完成范围

Qwen3-0.6B F16 GGUF 的全部 28 层 gate/up/down，共 84 个完整矩阵、504 MiB，均已接入 HBF 同步依赖。固定 44-token 输入，greedy 输出 8 个 token；KV 保持原生 GPU F16。真实 GPU 执行整个模型，HBF 对选中的 FFN 权重访问进行符号内容与时序模拟，真实权重字节仍在 GPU。

使用统一的 512 MiB 配置，地址连续覆盖 `[0, 528482304)`，余量 8 MiB。初始化仅普通写登记区域，初始化完成后确定请求 t0。通道、bank 并行度、时延与缓冲预算均与 F1/F2 相同。

F3 复用 F1 已校验的 native 记录、18072 个窗口及计算表，没有新增 native 运行。共享表 SHA256：`{f.sha(out/'compute-table.json')}`。GPU 程序及 DLL 与 F1/F2 完全相同，运行来源的 {len(identity['sources'])} 个文件哈希已核验并保存实验入口快照。

## 三阶段对照

| 指标 | F1：1 层 | F2：4 层 | F3：28 层 |
|---|---:|---:|---:|
{comparison}

共享 G2 零等待基线：TTFT {milliseconds(result['G2']['ttft_ps'])} ms，平均 TPOT {milliseconds(result['G2']['tpot_ps'])} ms，最后 token 时刻 {milliseconds(result['compute_ps'])} ms。各阶段共用一份 GPU 活动时间表，不将 CPU 间隙或仿真软件执行耗时计入模型时钟。

F3 实测累计等待为 F2 的 {result['total_wait_ps']/stages['F2']['total_wait_ps']:.6g} 倍。此比例描述当前参数与固定请求，不代表其他调度、并行方式、缓存状态或硬件的通用比例。

## F3 验证证据

- 全部 84 个矩阵在 8 个实际步骤中各读取一次，共 {coverage['parent_reads']} 次父读、{coverage['cumulative_read_bytes']//1024**2} MiB（3.9375 GiB）有效读取。
- {coverage['read_globals']:,} 个 4 KiB 读 Global、{coverage['read_fragments']:,} 个 64 B 读片段，以及 {coverage['write_fragments']:,} 个初始化写片段全部完成；没有逻辑失败或 attempt 错误。
- 实际后端事件数 {result['events_processed']:,}。在线审计峰值活动片段/attempt 为 {result['online_audit']['peak_live_fragments']}/{result['online_audit']['peak_live_attempts']}；后端自身完成历史仍可能增长，不能把活动预算视为总内存上限。
- token、结束原因、消费者序列和完整 logits 与 native 逐位一致；输出 `{native['tokens']}`，结束原因 `{native['stop_reason']}`。
- 核验每个消费者完整矩阵范围及稳定地址；全部 Global 完成后才允许对应 CUDA 消费者提交。计算表完全消费，逐段时钟连续，逐 token 时间残差均为 0 ps，Host/Device 正常排空。
- Python 10 项检查通过；保存结果再次离线审计通过。缺父读、错地址、少片段、错 token 时钟、错计算段时长的 5 类内存副本均被拒绝；这些是审计器负例，不是实际后端故障注入。

## 逐 token 配对

时间单位 ms，相对于初始化后的请求 t0。

| 步骤 | token ID | G2 累计计算 | 累计 HBF 等待 | F3 G3 时刻 | 残差（ps） |
|---|---:|---:|---:|---:|---:|
{per_token}

## 软件成本与文件

F3 进程耗时 {cost['process_wall_seconds']:.3f} 秒（约 {cost['process_wall_seconds']/60:.1f} 分钟）；后端初始化 {phases['backend_initialization']:.6f} 秒，读调用及在线审计合计 {phases['backend_read_calls_including_online_audit']:.6f} 秒，关闭调用 {phases['backend_finish']:.9f} 秒。峰值 Windows working set 为 {cost['peak_working_set_bytes']/1024**2:.3f} MiB。这些是软件运行成本，不能当作模拟 token 延迟、显存占用或真实硬件速度。

结构化结果：[gpu-f3.json](validation/gpu-f3.json)。批次保留完整布局/选区、有效配置、模型/构建哈希、实际运行源码快照、已核验 native 参考、计算表、完整 logits、GPU/API/分段记录、逐父读记录、逐 token 配对表、在线审计汇总、进程日志和文件哈希索引。不保留逐片段全量 JSON 或 GPU 中间数组；模型本体通过路径与哈希标识。

```powershell
python experiments/gpu_ffn/validate.py --output output/gpu-ffn/20261104-f3-001 --negative-checks
```

重跑需使用新目录，并显式给出足够的软件运行预算：

```powershell
python experiments/gpu_ffn/run.py --stage F3 --reference output/gpu-ffn/20261104-f1-001 --model <Qwen3-0.6B-F16.gguf> --cuda-root <CUDA-directory> --output output/gpu-ffn/f3-new --timeout 21600
```

结论限定为本模型、本输入、8 步、原生 KV 和指定 HBF 配置下全部 FFN 消费者的接入、数值及模拟时间核验。attention、embedding、输出层等未纳入 HBF 权重选区；这不证明全部模型权重适配、实际权重卸载或真实 HBF 硬件性能。
'''
(ROOT/'docs/GPU_F3_RESULTS.md').write_text(report, encoding='utf8')
plan_path = ROOT/'docs/GPU_FFN_EXPANSION_PLAN.md'
plan_text = plan_path.read_text(encoding='utf8')
plan_text = plan_text.replace('F3 已实现，完整批次 `output/gpu-ffn/20261104-f3-001/` 正在运行，结果待验收。',
                              '[F3](GPU_F3_RESULTS.md) 已完成全量运行并通过验证，三级实验全部完成。')
plan_text = plan_text.replace('F2 已实际运行通过，F3 全量运行进行中。',
                              'F2/F3 均已实际运行通过；三阶段对照见 [F3 总报告](GPU_F3_RESULTS.md)。')
plan_path.write_text(plan_text, encoding='utf8')
f2_path = ROOT/'docs/GPU_F2_RESULTS.md'
f2_text = f2_path.read_text(encoding='utf8').replace('F3 尚未执行。', '后续 [F3](GPU_F3_RESULTS.md) 已完成并通过全 FFN 验证。')
f2_text = f2_text.replace('尚未证明全部 28 层 FFN、全部模型权重适配或实际权重卸载。',
                         '全部 28 层 FFN 的后续验收见 F3 总报告；全部模型权重适配及实际权重卸载不在本实验范围。')
f2_path.write_text(f2_text, encoding='utf8')
f.write(out/'artifact-index.json', {'files': [
    {'path': str(p.relative_to(out)), 'bytes': p.stat().st_size, 'sha256': f.sha(p)}
    for p in sorted(out.rglob('*')) if p.is_file() and p != out/'artifact-index.json']})
for item in f.read(out/'artifact-index.json')['files']:
    f.require(f.sha(out/item['path']) == item['sha256'], 'Artifact hash mismatch')
print('F3 report, structured summary, and artifact index written and verified.')
