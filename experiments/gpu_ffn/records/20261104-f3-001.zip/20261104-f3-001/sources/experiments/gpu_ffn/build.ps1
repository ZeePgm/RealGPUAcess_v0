param(
 [Parameter(Mandatory=$true)][string]$CudaRoot,
 [string]$BuildDir=(Join-Path $PSScriptRoot '../../build-ffn'),
 [string]$CudaArchitectures='120a-real',
 [int]$Jobs=6
)
$ErrorActionPreference='Stop'
if($Jobs -lt 1){throw 'Jobs must be positive'}
$taskVswhere=Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio/Installer/vswhere.exe'
$taskVs=& $taskVswhere -latest -version '[17.0,18.0)' -products '*' -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath
if(!$taskVs){throw 'Visual Studio 2022 C++ build tools not found'}
$env:VSLANG='1033'
& (Join-Path $taskVs 'Common7/Tools/Launch-VsDevShell.ps1') -Arch amd64 -HostArch amd64 -SkipAutomaticLocation
$taskCuda=(Resolve-Path -LiteralPath $CudaRoot).Path
$env:CUDA_PATH=$taskCuda
$env:CUDACXX=Join-Path $taskCuda 'bin/nvcc.exe'
$env:PATH=(Join-Path $taskCuda 'bin')+';'+(Join-Path $taskCuda 'bin/x64')+';'+$env:PATH
$taskCmake=Join-Path $taskVs 'Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/cmake.exe'
$taskNinja=Join-Path $taskVs 'Common7/IDE/CommonExtensions/Microsoft/CMake/Ninja/ninja.exe'
& $taskCmake -S $PSScriptRoot -B $BuildDir -G Ninja '-DCMAKE_BUILD_TYPE=Release' "-DCMAKE_CUDA_ARCHITECTURES=$CudaArchitectures" "-DCUDAToolkit_ROOT=$taskCuda" "-DCMAKE_MAKE_PROGRAM=$taskNinja"
if($LASTEXITCODE -ne 0){throw 'Configure failed'}
& $taskCmake --build $BuildDir --target gpu_ffn ffn_audit_tests --parallel $Jobs
if($LASTEXITCODE -ne 0){throw 'Build failed'}
& (Join-Path $taskVs 'Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/ctest.exe') --test-dir $BuildDir --output-on-failure
if($LASTEXITCODE -ne 0){throw 'Online audit tests failed'}
